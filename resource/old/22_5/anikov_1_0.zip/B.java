import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.DecimalFormat;


public class B {

  public void doIt() throws IOException {
    String className = this.getClass().getSimpleName();
    boolean small = true;
    boolean practice = false;
    boolean out = false;
    
    String fileName = className + "-" + (small ? "small" : "large")
        + (practice ? "-practice" : (small ? "-attempt0" : "")) + ".in";
    String outFileName = className + "-" + (small ? "small" : "large")
        + (practice ? "-practice" : (small ? "-attempt0" : "")) + ".out";
    BufferedReader reader = new BufferedReader(new InputStreamReader(this.getClass()
        .getResourceAsStream(fileName)));

    PrintWriter writer = null;

    if (!out) {
      writer = new PrintWriter(new FileWriter(outFileName));
    }

    String o = "";
    String res = "";
    String line = reader.readLine();
    int cases = Integer.parseInt(line);

    for (int ncase = 0; ncase < cases; ncase++) {
      line = reader.readLine();
      String[] parts = line.split(" ");
      int C = Integer.parseInt(parts[0]);
      int D = Integer.parseInt(parts[1]);
      
      long[] p = new long[C];
      long[] v = new long[C];
      
      for (int i = 0; i < C; i++) {
        line = reader.readLine();
        parts = line.split(" ");
        p[i] = Long.parseLong(parts[0]);
        v[i] = Long.parseLong(parts[1]);
      }

      
      double min = 0;
      double max = 20000000;
      while (max - min > 1E-10) {
        double m = (max + min) / 2;
        
        double l = -20000000;
        boolean good = true;
        for (int i = 0; i < p.length; i++) {
          for (int j = 0; j < v[i]; j++) {
            double rg = l + D;
            if (rg > p[i] + m) {
              good = false;
              break;
            }
            if (l + D < p[i] - m) {
              l = p[i] - m;
            } else {
              l = l + D;
            }
          }
          if (!good) {
            break;
          }
        }
        if (good) {
          max = m;
        } else {
          min = m;
        }
      }
      DecimalFormat df = new DecimalFormat("#.############");
      res = "" + df.format(min);
      o = "Case #"+ (ncase + 1) + ": " + res;
      if (out) {
        System.out.println(o);
      } else {
        writer.println(o);
      }

    }
    if (!out) {
      writer.flush();
      writer.close();
    }

  }

  public static void main(String[] args) throws IOException {
    B a = new B();
    a.doIt();
  }

}
